딸깍 헤더 아이콘 — Lucide 기반, stroke-width 2.75 (Organic 규정)

new-tab.svg   새 탭에서 열기        Lucide: external-link
export.svg    내보내기 (로컬 다운로드)  Lucide: download
save.svg      저장 (로컬스토리지에)     Lucide: save
load.svg      불러오기 (로컬스토리지에서) Lucide: folder-open
reset.svg     초기화                Lucide: rotate-ccw

stroke="#ffffff" 고정 — 어두운 바탕용입니다.
버튼 색을 따라가게 하려면 SVG를 인라인으로 붙이고 stroke를 currentColor로 바꾸세요.
헤더 권장 크기 18px, 라벨과의 간격 7px.
초기화는 파괴적 동작이므로 확인 모달과 함께 쓰세요.
